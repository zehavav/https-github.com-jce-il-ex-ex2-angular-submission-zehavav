	// create the module and name it myApp
	var myApp = angular.module('myApp', ['ngRoute']);

	// configure our routes
	myApp.config(function($routeProvider) {
		$routeProvider

			// route for the home page
			.when('/', {
				templateUrl : 'pages/home.html',
				controller  : 'mainController'
			})

			// route for the project page
			.when('/project', {
				templateUrl : 'pages/project.html',
				controller  : 'projectController'
			})

			// route for the contact page
			.when('/contact', {
				templateUrl : 'pages/contact.html',
				controller  : 'contactController'
			});
	});

	// create the controller and inject Angular's $scope
	myApp.controller('mainController', function($scope) {
		// create a message to display in our view
		$scope.message = 'Hi you are Home';
	});

	myApp.controller('projectController', function($scope) {
		$scope.message = 'Look! I am in project page.';
	});

	myApp.controller('contactController', function($scope) {
		$scope.message = 'Contact us!';
	});